export const environment = {
  production: true,
  apiUrl: 'http://localhost:5296/api' // Change this to your production API URL when deploying
}; 