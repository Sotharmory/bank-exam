import { Component } from '@angular/core';

@Component({
  selector: 'app-exam-management',
  imports: [],
  templateUrl: './exam-management.component.html',
  styleUrl: './exam-management.component.css'
})
export class ExamManagementComponent {

}
